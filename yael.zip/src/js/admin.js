/**
 * Admin scripts
 */

( function( $ ) {
    "use strict";

    $( function() {

        //= customizer/alpha_color_picker.js
        //= admin/metaboxes.js

    } );

} )( jQuery );
