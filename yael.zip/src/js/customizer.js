/**
* Custom code for WP Customizer
*/

( function( $ ) {
    "use strict";

    $( function() {

       /*----------------------------------------------------------------------------
          Header Controls
       ----------------------------------------------------------------------------*/
       //= customizer/postMessage/header.js
       //= customizer/postMessage/footer.js

       /*----------------------------------------------------------------------------
          General Controls
       ----------------------------------------------------------------------------*/
       //= customizer/postMessage/general.js

    } );

} )( jQuery );
