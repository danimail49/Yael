/**
 * Yael 3rd party scripts
 */

//= ../vendor/materialize/dist/js/materialize.js
